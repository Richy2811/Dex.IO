package at.fhtw.dexio.pokedex;

import java.util.List;

public class PokedexEntryDTO {
    private String name;
    private String url;
    private List<PokemonTypeDTO> types;

    public String getName() {
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public String getURL() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setName(String name) {
        this.name = name;
    }

    //FÜr Teambuilder
    public List<PokemonTypeDTO> getTypes() { // Getter for types
        return types;
    }

    public void setTypes(List<PokemonTypeDTO> types) { // Setter for types
        this.types = types;
    }
    @Override
    public String toString() {
        //list view uses toString() method to determine which text to display in cells
        return name;
    }


}
