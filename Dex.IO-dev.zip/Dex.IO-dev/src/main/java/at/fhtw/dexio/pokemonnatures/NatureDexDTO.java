package at.fhtw.dexio.pokemonnatures;

import java.util.List;

public class NatureDexDTO {
    List<NatureEntryDTO> results;

    public List<NatureEntryDTO> getResults() {
        return results;
    }
}
