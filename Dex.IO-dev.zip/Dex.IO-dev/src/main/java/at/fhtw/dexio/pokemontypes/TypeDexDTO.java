package at.fhtw.dexio.pokemontypes;

import java.util.List;

public class TypeDexDTO {
    private List<TypeEntryDTO> results;

    public List<TypeEntryDTO> getResults() {
        return results;
    }
}
