package at.fhtw.dexio.pokemontypes;

public class TypeSpriteDTO {
    private String name_icon;

    public String getName_icon() {
        return name_icon;
    }
}
