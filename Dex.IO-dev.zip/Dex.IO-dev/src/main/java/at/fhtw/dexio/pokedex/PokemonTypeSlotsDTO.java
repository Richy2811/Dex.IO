package at.fhtw.dexio.pokedex;

public class PokemonTypeSlotsDTO {
    private PokemonTypeDTO type;

    public PokemonTypeDTO getType() {
        return type;
    }
}
