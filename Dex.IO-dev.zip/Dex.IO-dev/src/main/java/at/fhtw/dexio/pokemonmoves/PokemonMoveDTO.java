package at.fhtw.dexio.pokemonmoves;

public class PokemonMoveDTO {
    private MoveEntryDTO move;

    public MoveEntryDTO getMove() {
        return move;
    }
}
