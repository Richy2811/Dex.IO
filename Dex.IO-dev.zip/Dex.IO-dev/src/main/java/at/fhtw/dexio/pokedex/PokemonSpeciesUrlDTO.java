package at.fhtw.dexio.pokedex;

public class PokemonSpeciesUrlDTO {
    private String url;

    public String getUrl() {
        return url;
    }
}
