package at.fhtw.dexio.pokedex;

public class PokemonSpriteDTO {
    private String front_default;
    private String front_shiny;

    public String getFront_default() {
        return front_default;
    }

    public String getFront_shiny() {
        return front_shiny;
    }
}
