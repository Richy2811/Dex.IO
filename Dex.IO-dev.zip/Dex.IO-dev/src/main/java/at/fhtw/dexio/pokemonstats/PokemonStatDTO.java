package at.fhtw.dexio.pokemonstats;

public class PokemonStatDTO {
    private Integer base_stat;

    public Integer getBase_stat() {
        return base_stat;
    }
}
