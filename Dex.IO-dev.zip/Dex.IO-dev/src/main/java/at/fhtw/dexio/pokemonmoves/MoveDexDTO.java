package at.fhtw.dexio.pokemonmoves;

import java.util.List;

public class MoveDexDTO {
    private List<MoveEntryDTO> results;

    public List<MoveEntryDTO> getResults() {
        return results;
    }
}
