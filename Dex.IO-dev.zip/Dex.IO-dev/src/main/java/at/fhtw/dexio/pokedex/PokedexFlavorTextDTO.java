package at.fhtw.dexio.pokedex;

public class PokedexFlavorTextDTO {
    private String flavor_text;
    private PokedexFlavorTextLanguageDTO language;

    public String getFlavor_text() {
        return flavor_text;
    }

    public PokedexFlavorTextLanguageDTO getLanguage() {
        return language;
    }
}
