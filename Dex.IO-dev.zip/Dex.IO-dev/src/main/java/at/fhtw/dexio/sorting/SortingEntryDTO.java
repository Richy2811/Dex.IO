package at.fhtw.dexio.sorting;

import at.fhtw.dexio.pokedex.PokemonTypeDTO;

import java.util.List;

public class SortingEntryDTO {
    private String name;
    private List<PokemonTypeDTO> types;

    public SortingEntryDTO(String name, List<PokemonTypeDTO> types) {
        this.name = name;
        this.types = types;
    }

    public String getName() {
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public List<PokemonTypeDTO> getTypes() {
        return types;
    }

    @Override
    public String toString() {
        return name; // This will be displayed in the ListView
    }
}
