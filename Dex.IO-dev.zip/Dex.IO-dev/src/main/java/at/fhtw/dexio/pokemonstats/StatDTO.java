package at.fhtw.dexio.pokemonstats;

public class StatDTO {
    private String name;

    public String getName() {
        return name;
    }
}
