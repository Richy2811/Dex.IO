package at.fhtw.dexio.pokedex;

public class PokedexFlavorTextLanguageDTO {
    private String name;

    public String getName() {
        return name;
    }
}
